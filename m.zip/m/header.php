<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from html.kodesolution.com/2023/immigro-html/index-3.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 07 Feb 2024 14:39:56 GMT -->
<head>
<meta charset="utf-8">
<title>Impact Hub Institute</title>

<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="shortcut icon" href="images/logo.png" type="image/png">
<link rel="icon" href="images/logo.png" type="image/png">

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>
<body>
<div class="page-wrapper">



<header class="main-header header-style-three">

<div class="header-top">
<div class="inner-container">
<div class="top-left">

<ul class="list-style-one">
<li><i class="fa fa-envelope"></i> <a href="Impacthub9gmail.com"><span class="__cf_email__" data-cfemail="056b6060616d60697545666a6875646b7c2b666a68">Impacthub9gmail.com</span></a></li>
<li><i class="fa fa-map-marker"></i> Top floor,gulmarg store Main market,ratia</li>
<li><i class="fa fa-phone"><a href="tel:+919588189877" ></i> +919588189877</li></a>
</ul>
</div>
<div class="top-right">
<ul class="social-icon-one">
<li><a href="#"><span class="fab fa-twitter"></span></a></li>
<li><a href="#"><span class="fab fa-facebook-f"></span></a></li>
<li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
<li><a href="#"><span class="fab fa-instagram"></span></a></li>
</ul>
</div>
</div>
</div>
<style>
@media only screen and (max-width: 1023px){
#img,#h5 {
    display:none;
}
}


    </style>

<div class="header-lower">

<div class="main-box">
<div class="logo-box">
<div class="logo"><a href="index.php"><img src="images/logo.png" alt title="Tronis" style="height:100px; width: 150px; margin-top: -20px;" id="img">
<h5 style="margin-left: 18px;
    font-size: smaller;
    margin-bottom: 5px;
    color:white;" id="h5">Impact Hub Institute</h5>
</a></div>
</div>

<div class="nav-outer">
<nav class="nav main-menu">
<ul class="navigation">
<li><a href="index.php">Home</a></li>
<li><a href="about.php">About</a></li>
<li class="dropdown"><a href="#">Country</a>

<ul>
<li><a href="australia.php">Australia</a></li>
<li><a href="usa.php">USA</a></li>
<li><a href="canada.php">Canada</a></li>
<li><a href="uk.php">UK</a></li>
</ul>
</li>


<li class="dropdown"><a href="#">Coaching</a>


<ul>
<li><a href="pte.php">PTE</a></li>
<li><a href="iltes.php">IELTS</a></li>
</ul>
</li>


<li><a href="contact.php">Contact</a></li>
</ul>
</nav>

<div class="outer-box">
<a href="tel:+92(8800)9806" class="info-btn">
<img class="icon" src="images/icons/icon-phone.png" alt>
<small class="title">Call Anytime</small>
<strong class="text">+ 9195881-89877</strong>
</a>

<a href="contact.php" class="theme-btn btn-style-one"><span class="btn-title">Book Consultation</span></a>

<div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
</div>
</div>
</div>
</div>


<div class="mobile-menu">
<div class="menu-backdrop"></div>

<nav class="menu-box">
<div class="upper-box">
<div class="nav-logo"><a href="index.php"><img src="images/logo.png" alt title>



</a></div>
<div class="close-btn"><i class="icon fa fa-times"></i></div>
</div>
<ul class="navigation clearfix">

</ul>
<ul class="contact-list-one">
<li>

<div class="contact-info-box">
<i class="icon lnr-icon-phone-handset"></i>
<span class="title">Call Now</span>
<a href="tel:+919588189877">+9195881-89877</a>
</div>
</li>
<li>

<div class="contact-info-box">
<span class="icon lnr-icon-envelope1"></span>
<span class="title">Send Email</span>
<a href="Impacthub9gmail.com"><span class="__cf_email__" data-cfemail="056d60697545666a6875646b7c2b666a68">Impacthub9gmail.com</span></a>
</div>
</li>
<li>

<div class="contact-info-box">
<span class="icon lnr-icon-clock"></span>
<span class="title">Send Email</span>
Mon - Sat 8:00 - 6:30, Sunday - CLOSED
</div>
</li>
</ul>
<ul class="social-links">
<li><a href="#"><i class="fab fa-twitter"></i></a></li>
<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
<li><a href="#"><i class="fab fa-pinterest"></i></a></li>
<li><a href="#"><i class="fab fa-instagram"></i></a></li>
</ul>
</nav>
</div>

<div class="search-popup">
<span class="search-back-drop"></span>
<button class="close-search"><span class="fa fa-times"></span></button>

</div>


<div class="sticky-header">
<div class="auto-container">
<div class="inner-container">

<div class="logo">
<a href="index.php" title><img src="images/logo.png" alt title></a>
</div>

<div class="nav-outer">

<nav class="main-menu">
<div class="navbar-collapse show collapse clearfix">
<ul class="navigation clearfix">

</ul>
</div>
</nav>

<div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
</div>
</div>
</div>
</div>
</header>
